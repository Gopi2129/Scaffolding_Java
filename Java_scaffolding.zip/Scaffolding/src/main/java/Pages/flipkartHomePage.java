package Pages;


import java.io.IOException;
import Support.Xpath;
import Support.ReadProperty;
import Support.SeleniumMethods;

public class flipkartHomePage extends SeleniumMethods{
	
	Xpath xp;
	public flipkartHomePage(){
	 xp=new Xpath();
	}
	
	public void LaunchBrowser(String url) throws IOException {
		ReadProperty rp=new ReadProperty();
		launchUrl(rp.getProperty("URL"));
	}
	
	public void cancelLoginPopup() {
		clickElement(xp.Xpath_Btn_Cancel);
	}
	
	public void clickGivenBanner(Integer i) {
		clickListOfWebElements(xp.Xpath_Lbl_Banner,i);		
	}

}
