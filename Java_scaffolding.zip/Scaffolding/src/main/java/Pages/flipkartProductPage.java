package Pages;


import java.util.List;
import org.openqa.selenium.WebElement;

import Support.SeleniumMethods;
import Support.Xpath;

public class flipkartProductPage extends SeleniumMethods{
	Xpath xp;

	public flipkartProductPage(){
		 xp=new Xpath();

	}
	public void hoverOnProductTitle(String productTitle) throws InterruptedException {
		String element=String.format(xp.Xpath_Lbl_ProductTitle,productTitle);
		System.out.println();
		printTextOfElement(element);
		Thread.sleep(3000);
		HoverOnElement(element);	
	}
	
	
	public void closeAllBrowser() {
		closeBrowser();
	}
	

	public void printSubMenus() {


List<WebElement> Xpath_sectioncount =getListOfWebElements(xp.sectioncount);

		for(int i=1;i<=Xpath_sectioncount.size();i++) {
			String elementtext=xp.printalltag.replace( "PARAMETER",String.valueOf(i));

			List<WebElement>   Xpath_printalltag=getListOfWebElements(elementtext);
					
					int k=1;
					for(WebElement element:Xpath_printalltag) {
						if(element.getAttribute("class").equals("_3QN6WI _1MMnri _32YDvl") ||  element.getAttribute("class").equals("_3QN6WI _1MMnri") ) {
							System.out.println("\033[0;1m"+element.getText());
							k=1;
						}
						else {
							System.out.println("\033[0;0m"+k+". "+element.getText());
							k++;
						}
					}		
		}
	}




}
