package Support;

public class Xpath {
	public  String Xpath_Btn_Cancel = "//button[text()='✕']";
	public  String Xpath_Lbl_Banner = "//div[@class='eFQ30H']";
	public  String Xpath_Lbl_ProductTitle = "//span[text()='%s']";
	public String printalltag= "(//div[@class='_1fwVde'])[PARAMETER]/a | (//div[@class='_1fwVde'])[PARAMETER]/span";
	public String sectioncount= "(//div[@class='_1fwVde'])";
}
