package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


    
@CucumberOptions(tags = "@tag", features = {"C:\\Users\\GDK21\\eclipse-workspace\\SeleniumAssignment-Suresh\\src\\test\\java\\Feature\\FlipkartTestFIle.feature"}, glue = {"stepDefinitions"},
                 plugin = {})
    
public class testRunner extends AbstractTestNGCucumberTests {
    
}

