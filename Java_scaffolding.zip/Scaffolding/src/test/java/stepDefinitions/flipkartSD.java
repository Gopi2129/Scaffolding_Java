package stepDefinitions;

import java.io.IOException;

import Pages.flipkartHomePage;
import Pages.flipkartProductPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class flipkartSD {
	flipkartHomePage homepage;
	flipkartProductPage productpage;
	
	public flipkartSD(){
		this.homepage= new flipkartHomePage();
		this.productpage=  new flipkartProductPage();
	}
	
@Given("I want to launch flipkart")
public void i_want_to_launch_flipkart() throws IOException {
	homepage.LaunchBrowser("https://www.flipkart.com/");
}
@Then("cancel login popup")
public void cancel_login_popup() {
	homepage.cancelLoginPopup();
}
@Then("click on any {int} banner")
public void click_on_any_banner(Integer int1) {
	homepage.clickGivenBanner(int1);
}
@Then("Hover on the product title {string}")
public void hover_on_the_product_title(String string) throws InterruptedException {
	productpage.hoverOnProductTitle(string);
}
@Then("print all submenus")
public void print_all_submenus() {
	productpage.printSubMenus();
}
@Then("close the browser")
public void close_the_browser() {
	productpage.closeAllBrowser();
}

}
