package com.DataProvider;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.testng.annotations.DataProvider;

public class credentials {
	static credentials objReadCsvFile;

	@DataProvider(name = "credentials")
	public static Object[][] csvFileReader() throws IOException {
		String[][] testData = null;

		// Get the workbook
		Reader fileInputStream = new FileReader(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\csv\\credentials.csv");
		Iterable<CSVRecord> records = CSVFormat.EXCEL.parse(fileInputStream);

		int numberOfRecords = 0;
		int numberOfColumns = 0;

		for (CSVRecord record : records) {
			++numberOfRecords;
			numberOfColumns = record.size();
		}

		testData = new String[numberOfRecords - 1][numberOfColumns];

		int currentRecord = 0;

		fileInputStream = new FileReader(System.getProperty("user.dir")
				+ "\\src\\main\\resources\\csv\\credentials.csv");
		records = CSVFormat.EXCEL.parse(fileInputStream);

		for (CSVRecord record : records) {

			System.out.println("Reading test data ");
			if (record.getRecordNumber() == 1) {
				System.out.println("record = " + record);
				continue;
			}

			for (int i = 0; i < record.size(); i++) {
				testData[currentRecord][i] = record.get(i);

			}
			currentRecord++;
		}

		return testData;
	}

}
