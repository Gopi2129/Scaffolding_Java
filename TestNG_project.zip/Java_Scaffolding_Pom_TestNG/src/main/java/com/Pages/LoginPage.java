package com.Pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import com.DataProvider.credentials;
import com.Support.BaseClass;
import com.Support.ReadProperty;


public class LoginPage extends BaseClass{
	
	ReadProperty readproperty;

	@FindBy(xpath = "//h1")	
	WebElement input_userName;
	
	@FindBy(xpath = "//*[@id='signupModalButton']")
	WebElement input_password;
	
	@FindBy(xpath = "//*[@id='signupModalButton']")
	WebElement button_login;

	public LoginPage() {
	PageFactory.initElements(driver, this);
	}

    public void LaunchApplication() throws IOException {
    	initiateDriver();
    }
  

 

    @Test(dataProvider = "credentials", dataProviderClass = credentials.class)   
    public void loginToApplication(String loginData[]) {
    	System.out.println(loginData[0]);
    	System.out.println(loginData[1]);

     sendKeys(input_userName,readproperty.getProperty("Username"));
     sendKeys(input_password,readproperty.getProperty("Password"));
     click(button_login);
    }

}
