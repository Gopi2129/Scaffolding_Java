package com.Support;

import java.awt.Robot;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.TakesScreenshot;

import com.aventstack.extentreports.Status;

public class BaseClass {
	
	public static WebDriver driver;
	public static Actions objAction;
	public static JavascriptExecutor executor;
	public static Select objselect;
	static Actions actions;
	static Robot r;
	ReadProperty readproperty;
	
	
		public void  initiateDriver() throws IOException {
			readproperty =new ReadProperty();
      String browserName=readproperty.getProperty("Browser").toLowerCase();
	        switch (browserName) {
	            case "chrome":
	            	 ChromeOptions options = new ChromeOptions();

	                 // Headless mode (run Chrome without opening a GUI window)
	                 // options.addArguments("--headless");
	         		options.addArguments("--version="+readproperty.getProperty("Version"));

	                 // Disable extensions
	                  options.addArguments("--disable-extensions");

	                 // Disable info bars (e.g., Chrome is being controlled by automated test software)
	                  options.addArguments("--disable-infobars");

	                 // Disable notifications
	                  options.addArguments("--disable-notifications");

	                 // Disable image loading
	                  options.addArguments("--blink-settings=imagesEnabled=false");

	                 // Accept insecure certificates
	                  options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);

	                  //Set a specific download directory
	                  Map<String, Object> prefs = new HashMap<>();
	                  prefs.put("download.default_directory", System.getProperty("user.dir")+"\\src\\main\\resources\\csv");
	                  options.setExperimentalOption("prefs", prefs);

	                 // Initialize WebDriver with ChromeOptions
	                driver = new ChromeDriver(options);
	                break;
	            case "firefox":
	                driver = new FirefoxDriver();
	                break;
	            case "ie":
	            case "internetexplorer":
	                driver = new InternetExplorerDriver();
	                break;
	            case "edge":
	                driver = new EdgeDriver();
	                break;
	            default:
	                throw new IllegalArgumentException("Unsupported browser: " + browserName);
	        }
               driver.manage().window().maximize();
               pageLoadTime(30);
               driver.get(readproperty.getProperty("URL"));
	    }

	public void ExpectWait_Visible(WebElement element, int seconds) {

		WebDriverWait waiter = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		waiter.until(ExpectedConditions.visibilityOf(element));
	}

	public void explicitWait_Selected(WebElement element, int seconds) {

		WebDriverWait waiter = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		waiter.until(ExpectedConditions.elementToBeSelected(element));
	}


	public void explicitWait_Clickable(WebElement element, int seconds) {
		WebDriverWait waiter = new WebDriverWait(driver, Duration.ofSeconds(seconds));
		waiter.until(ExpectedConditions.elementToBeClickable(element));
	}

	public void validateMessage(WebElement element, String expectedMessage, String reportMessage) {
		String actual = element.getText();
		Assert.assertEquals(actual, expectedMessage);
		ExtentTestManager.getTest().log(Status.PASS, reportMessage + "- " + actual);
	}

	public int generateRandomNum(int from, int to) {
		Random rd = new Random();
		return rd.nextInt(from, to);
	}
	
	public void pageLoadTime(int seconds) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(seconds));
	}
	
	public void click(WebElement element) {
		element.click();
	}
	public void sendKeys(WebElement element,String text) {
		element.sendKeys(text);
	}

	
	 
	 public  File takeScreenshot() {
         // Convert WebDriver object to TakesScreenshot
         TakesScreenshot screenshot = (TakesScreenshot) driver;

         // Capture screenshot as File
         File source = screenshot.getScreenshotAs(OutputType.FILE);

         return source;
     }

}
