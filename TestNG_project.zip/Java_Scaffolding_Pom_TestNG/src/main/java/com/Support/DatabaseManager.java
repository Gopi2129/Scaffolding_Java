package com.Support;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseManager {
	  static String url
      = "jdbc:mysql://localhost:3306/table_name"; // table details
  static String username = "rootgfg"; // MySQL credentials
  static String password = "gfg123";
  static String query
      = "select *from students";
	
	public void databseConnection() {
		
	}
	
	
	public static void main(String[] args) throws Exception
    {
       // query to be run
        Class.forName(
            "com.mysql.cj.jdbc.Driver"); // Driver name
        Connection con = DriverManager.getConnection(
            url, username, password);
        System.out.println(
            "Connection Established successfully");
        Statement st = con.createStatement();
        ResultSet rs
            = st.executeQuery(query); // Execute query
        rs.next();
        String name
            = rs.getString("name"); // Retrieve name from db
 
        System.out.println(name); // Print result on console
        st.close(); // close statement
        con.close(); // close connection
        System.out.println("Connection Closed....");
    }

}
