package com.Support;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadProperty {
	Properties p;
	
	//read inputs from property file using read property method
	public ReadProperty () throws IOException{ 
	FileReader reader =  new FileReader (System.getProperty("user.dir")+"\\src\\main\\resources\\properties\\configuration.properties"); 
	p= new Properties();
	p.load(reader);
		
	}
	

		
	public void setProperty(String propertyname,String Propertyvalue) {
		p.setProperty(propertyname, Propertyvalue);
	
	}

		public String getProperty(String propertyname) {
		
		String Propertyvalue = p.getProperty(propertyname);
		return Propertyvalue;
	}

}
