package com.TestData;

public class Constants {
	
	public static  String register_message = "Thank you for registering with Tealium Ecommerce.";
	public static  String register_error_message ="There is already an account with this email address. If you are sure that it is your email address, click here to get your password and access your account.";
	public static String login_error_message ="Invalid login or password.";

}
